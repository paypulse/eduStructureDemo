var startGame=false;
var qIndex = 0;
var correctCnt=0;
var indicatorCnt=0;

var mouseDown=false;
var startPoint = false;
var startPosIdx=-1;

var img_blink= null

//문제 맞췄을 때
function goNextExam(){
	var cha2 = $('#star');

	cha2.addClass('star2').append("<img class='cha2' src='/web/resource/img/flower/fl2/cha2.png' style='position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%);'>");

	$(".star2").css("display", "block");
	$('.cha2').css('display','block');

	setTimeout(function(){
		$(".star2").css("display", "none");
		$('.cha2').css('display','none');
	}, 1500);
};

function _flower_start() {
  function gen_flowers(){
    var p = $("#flowers");
    for (var i=0; i < max_flowers; i ++){
      var imgIndex = (i%26) + 1;
      p.append("<img class='other' src='../fl/" + imgIndex +".png' style='position:absolute; display: none;'>");
    }
  }

  $("#flowers").css("display", "block");
	var img = $(".other");
  if (img.length == 0){
    gen_flowers();
    img = $(".other");
  }

	img.each(function (index, value) {
    	var image = $(this);
    	var x = Math.random() * 101;
    	var y = Math.random() * 101;
    	image.css("left", parseInt(1280 * x / 100) + "px");
    	image.css("top", y + parseInt(800 * y / 100) + "px");
    	image.css("display", "block");
    });

	fl_timer = setInterval(_flower_timer, 100);
}

function _flower_timer() {

	var img = $(".other");

	img.each(function (index, value) {

    	var image = $(this);
    	var x = Math.floor(Math.random() * 4);
    	var y = 30;
    	x += parseInt(image.css("left").replace("px",""));
    	y += parseInt(image.css("top").replace("px",""));
    	if (x > 1280) x = x - 1280;
    	if (y > 800) y = y - 800;
    	image.css("left", x + "px");
    	image.css("top", y + "px");
    });
}

function _flower_end() {

	if (fl_timer != null)
		clearInterval(fl_timer);

	fl_timer = null;

	var img = $(".other");

	img.each(function (index, value) {

    	var image = $(this);
    	image.css("display", "none");
  });
  $("#flowers").css("display", "none");
  $("#flowers").empty();

}

function startShowStar(){
  $(".star").css("opacity", 0);
  $("#star").css("display", "block");

  var i = 1;
  var ani = setInterval(function(){
    $(".star").css("opacity", 0);
    var t = $("#" + "starEffect_" + i);
    if (t.length){
      t.css("opacity", 1);
    }
    else{
      clearInterval(ani);
      ani = null;
      $(".star").css("opacity", 0);
      $("#star").css("display", "none");
    }
    i++;
  }, 50);
}


function loadStarAnimation(){
  function pad(n, width) {
    n = n + '';
    return n.length >= width ? n : new Array(width - n.length + 1).join('0') + n;
  }
  var div = $("#star");
  for (var i = 1; i < 32; i++ ){
    var img = $("<img class='star' style='opacity:0; position:absolute; left:0px; top:0px'>");
    img.attr("src", "../star/" + i + ".png");
    img.attr("id", "starEffect_" + i);
    img.appendTo(div);
  }
}


function goHome() {
  var aN = $("#anext");

  aN.on("ended", function(){
    aN.off("ended");
    window.location = home_url;
  });
  aN[0].play();

}

function goNext() {

   var aN = $("#anext");

   aN.on("ended", function(){
     aN.off("ended");
       window.location = right_url;
   });
   aN[0].play();

 }


 function goPage(pageUrl){

   var aN = $("#anext");

   aN.on("ended", function(){
     window.location = pageUrl;
   });
     aN[0].play();
 }

 function sa() {
   var audios = document.getElementsByTagName("audio");
   for (var i = 0; i < audios.length; i++) {
     var audio = audios[i];
     if (audio.id != "intro") {
       audio.onended = null;
       audio.pause();
       audio.currentTime = 0;
     }
   }
 }

 var jj = 1 ;
 function _blink(bid,ae) {
   if (img_blink != null) {
     clearInterval(img_blink);
   }

     var my_timer = ae ;
     img_blink = setInterval(function(){

     if(jj++ % 2 == 0){
         $("#"+bid).css("opacity","0");
     } else {
         $("#"+bid).css("opacity", "1");
     }
   }, my_timer);
 }

function popClose(){
  sa();
  $(".popup").css("opacity","0");
  $("#popup,#play_popup").css("z-index","0");
  $("#popClose,#play_popup").css("display","none");

}

function popUp(){
  sa();


  $("#popup").css("opacity","1");
  $("#popup").css("z-index","100");
  $("#play_popup").css("z-index","1001");
  $("#popClose,#play_popup").css("display","block");

  var audio = document.getElementById("a_popup");
  audio.play();

}

function _play_audio(file_name){
 sa();
 var ae = document.getElementById(file_name);
 ae.play();
}


function getAbsCoordsUp(e) {
  var x, y;
  if (e.type == "touchend"){
    x = e.changedTouches[0].pageX;
    y = e.changedTouches[0].pageY;
  }
  else{
    x = e.originalEvent.clientX;
    y = e.originalEvent.clientY;
  }

   return {absX:x, absY:y};
 }

 function getLocalCoords(elem, ev) {
   var ox = 0;
   var oy = 0;
   var first;
   var pageX, pageY;
   ox += elem.offset().left;
   oy += elem.offset().top;

   if (ev.type.startsWith("touch")) {
     first = ev.touches[0];
     pageX = first.pageX;
     pageY = first.pageY;
   } else {
     pageX = ev.pageX;
     pageY = ev.pageY;
   }
   return {
     'x': pageX - ox,
     'y': pageY - oy
   };
 }

 function recompositeCanvas() {
   var ctx = $("#mCanvas")[0].getContext('2d');
   ctx.drawImage(drawCanvas, 0, 0);
 }

 function clearCanvas() {
   var writable = $('#drawDiv');
   var size_w = parseInt(writable.css('width'), 10);
   var size_h = parseInt(writable.css('height'), 10);


   var ctxCanvas = $("#mCanvas")[0].getContext('2d');
   ctxCanvas.clearRect(0, 0, size_w, size_h);

   var ctxDraw = drawCanvas.getContext('2d');
   ctxDraw.clearRect(0, 0, size_w, size_h);
 }

 var xxx = -1000;
 var yyy = -1000;


 function scratchLine(can, x, y, fresh) {
   var ctx = can.getContext('2d');
   ctx.lineWidth = 20;
   ctx.lineCap = ctx.lineJoin = 'round';
   ctx.strokeStyle = 'rgba(251, 205, 0, 255)';
   ctx.beginPath();
   if (xxx == -1000) {
    ctx.moveTo(x + 0.01, y);
   } else {
    ctx.moveTo(xxx, yyy);
   }
   ctx.lineTo(x, y);
   ctx.stroke();

   xxx = x;
   yyy = y;
 }


 function checkPosition(e) {
   var retAbsCoords = getAbsCoordsUp(e);
   var x = retAbsCoords.absX;
   var y = retAbsCoords.absY;
   for (var i=2;i<tgDivInfo.length;i++) {
     if((parseInt(tgDivInfo[i].left)-100 <= x) && (parseInt(tgDivInfo[i].top)-100 <= y) &&
       ((parseInt(tgDivInfo[i].left)+parseInt(tgDivInfo[i].w)) >= x) && ((parseInt(tgDivInfo[i].top)+parseInt(tgDivInfo[i].h)) >= y)) {
       return i;
     }
   }
   return -1;

 }

 function defineMouseEvent() {
   $(window).on("mousemove touchmove", function(e){
     if (startGame && mouseDown && startPoint) {
       var local = getLocalCoords( $("#drawDiv"), e);
       scratchLine(drawCanvas, local.x, local.y, false);
       recompositeCanvas();
     }
   });

   $(window).on("mouseup touchend", function(e){
     if (startGame && startPoint) {
       clearCanvas();

       xxx = -1000;
       yyy = -1000;
       var chPos=checkPosition(e);
       /////////////////////////////////////////////////////////
       var chkImg=null;
       if (chPos > -1) {
         if (startPosIdx > -1) {

           if (startPosIdx == parseInt($("#tg"+chPos).attr("idx"))) {

             correctCnt++;
             if (startPosIdx==1) {chkImg=lineImg[0];}
             else if (startPosIdx==2) {chkImg=lineImg[1];}
             if (correctCnt == 1) {
               var adot=$("<img style='position:absolute;'>");
               adot.attr("src","adot.png");
               adot.appendTo($("#lineDiv"));
             }
             var add_line=$("<img style='position:absolute;'>");
             add_line.attr("src",chkImg);
             add_line.appendTo($("#lineDiv"));


              if (correctCnt > 1) {
                goNextExam();

                $("#a_correct").on("ended", function(){
                  clearInterval(img_blink);
                  //startShowStar();
                  $("#next").css("display","block");
                  $("#next_arrow").css("display","block");
                  _blink("next_arrow",500);
                });
              }


             $("#a_correct")[0].play();
           } else {
             $("#a_incorrect")[0].play();
           }

         }
         else {
           $("#a_incorrect")[0].play();
         }

       } else {
         $("#a_incorrect")[0].play();
       }
       /////////////////////////////////////////////////////////


     }
     //////////////////
     mouseDown = false;
     startPoint = false;
     startPosIdx=-1;

   });
 }

 function makeLineDiv() {
   var lineDiv= $("<div style='position:absolute;'>");
   lineDiv.attr("id","lineDiv");
   lineDiv.css({left:0, top:0, width:1280, height:800});
   lineDiv.appendTo($("#options"));
 }

 function makeTargetArea() {
   for (var i=0;i<tgDivInfo.length;i++) {
     var a = $("<div style='position:absolute;'>");
     a.attr("id","tg"+i);
     a.attr("idx", $("#q"+(i+1)).attr("idx"));
     a.css({left: tgDivInfo[i].left , top: tgDivInfo[i].top, width:tgDivInfo[i].w, height:tgDivInfo[i].h});
     a.appendTo($("#options"));
     if ((i == 0) || (i==1)) {
       a.on("mousedown touchstart", function(e) {
        e.preventDefault();
         mouseDown=true;
         startPoint=true;
         startPosIdx=parseInt($(this).attr("idx"));
       });
     }
   }
 }

 function makeCanvas() {
   var mcanvas = $("<canvas/>", {'class' : 'sctatch', 'id':'mCanvas'});
   mcanvas.prop({
                 width: drawDivInfo[0].w,
                 height: drawDivInfo[0].h,
             });
   mcanvas.appendTo($("#drawDiv"));

   drawCanvas = document.createElement('canvas');
   drawCanvas.width = parseInt(drawDivInfo[0].w);
   drawCanvas.height = parseInt(drawDivInfo[0].h);

 }

 function makeDrawDiv() {
   var a = $("<div style='position:absolute;'>");
   a.attr("id","drawDiv");
   a.css({left: drawDivInfo[0].left , top: drawDivInfo[0].top, width:drawDivInfo[0].w, height:drawDivInfo[0].h});
   a.appendTo($("#options"));
 }

 function configQuestion() {

   var question= questionInfo[qIndex];
   var a = $("<div style='position:absolute;'>");
   a.attr("id","q1");
   a.attr("idx",question.q1.idx);
   a.css({left: question.q1.left , top: question.q1.top,
          width:question.q1.width, height:question.q1.height});
   a.appendTo($("#options"));
   a.on("click", function() {
     startGame = false;
     sa();
     var auxAudio = document.getElementById("au1");
     auxAudio.onended = function(){
       startGame = true;
     }
     auxAudio.play();
   });

   var b = $("<div style='position:absolute;'>");
   b.attr("id","q2");
   b.attr("idx",question.q2.idx);
   b.css({left: question.q2.left , top: question.q2.top,
          width:question.q2.width, height:question.q2.height});
   b.appendTo($("#options"));

   b.on("click", function() {
     startGame = false;
     sa();
     var auxAudio = document.getElementById("au2");
     auxAudio.onended = function(){
       startGame = true;
     }
     auxAudio.play();
   });

   var c = $("<div style='position:absolute;'>");
   c.attr("id","q3");
   c.attr("idx",question.qq1.idx);
   c.css({left: question.qq1.left , top: question.qq1.top,
          width:question.qq1.width, height:question.qq1.height});
   c.appendTo($("#options"));
   c.on("click", function() {
     startGame = false;
     sa();
     var auxAudio = document.getElementById("au3");
     auxAudio.onended = function(){
       startGame = true;
     }
     auxAudio.play();
   });

   var d = $("<div style='position:absolute;'>");
   d.attr("id","q4");
   d.attr("idx",question.qq2.idx);
   d.css({left: question.qq2.left , top: question.qq2.top,
          width:question.qq2.width, height:question.qq2.height});
   d.appendTo($("#options"));
   d.on("click", function() {
     startGame = false;
     sa();
     var auxAudio = document.getElementById("au4");
     auxAudio.onended = function(){
       startGame = true;
     }
     auxAudio.play();
   });
 }

 function initQuestion() {
   $("#options").empty();
   makeLineDiv();
   configQuestion();

   makeDrawDiv();
   makeCanvas();
   makeTargetArea();
   defineMouseEvent();
}



function init() {

  //exbtnPosition();
  // loadStarAnimation();

  var intro = document.getElementById('a_intro');
  intro.play();
  intro.onended = function(){
    initQuestion();
    startGame=true;
    $("#click_pop,#play_audio").css("display","block") ;
  }
}

$(window).on("load", function() {
  init();
});
