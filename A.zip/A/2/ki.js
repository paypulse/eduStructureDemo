/**
 * File      : ki.js
 * Version   : 1.0.0
 * Date      : 2019.10.13
 * Create By : SANG
 */

var action = [];
var cur_index = 1;
var max_index = 6 ;
var load_finished = false;// 처음에 loading finish 여부
var qIndex = 0;
var minorStep = 0;
var timer_index = 0 ;
var first = false;
var second = false;
var page = 1 ;
var flash_index = 0;
var location_info = {"test": "test"};

//문제 맞췄을 때
function goNextExam(){
	var cha2 = $('#star');

	cha2.addClass('star2').append("<img class='cha2' src='/web/resource/img/flower/fl2/cha2.png' style='position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%);'>");

	$(".star2").css("display", "block");
	$('.cha2').css('display','block');

	setTimeout(function(){
		$(".star2").css("display", "none");
		$('.cha2').css('display','none');
	}, 1500);
};

// function _flower_start() {
//   function gen_flowers(){
//     var p = $("#flowers");
//     for (var i=0; i < max_flowers; i ++){
//       var imgIndex = (i%26) + 1;
//       p.append("<img class='other' src='../fl/" + imgIndex +".png' style='position:absolute; display: none;'>");
//     }
//   }

//   $("#flowers").css("display", "block");
// 	var img = $(".other");
//   if (img.length == 0){
//     gen_flowers();
//     img = $(".other");
//   }

// 	img.each(function (index, value) {
//     	var image = $(this);
//     	var x = Math.random() * 101;
//     	var y = Math.random() * 101;
//     	image.css("left", parseInt(1280 * x / 100) + "px");
//     	image.css("top", y + parseInt(800 * y / 100) + "px");
//     	image.css("display", "block");
//     });

// 	fl_timer = setInterval(_flower_timer, 100);
// }

// function _flower_timer() {

// 	var img = $(".other");

// 	img.each(function (index, value) {

//     	var image = $(this);
//     	var x = Math.floor(Math.random() * 4);
//     	var y = 30;
//     	x += parseInt(image.css("left").replace("px",""));
//     	y += parseInt(image.css("top").replace("px",""));
//     	if (x > 1280) x = x - 1280;
//     	if (y > 800) y = y - 800;
//     	image.css("left", x + "px");
//     	image.css("top", y + "px");
//     });
// }

// function _flower_end() {

// 	if (fl_timer != null)
// 		clearInterval(fl_timer);

// 	fl_timer = null;

// 	var img = $(".other");

// 	img.each(function (index, value) {

//     	var image = $(this);
//     	image.css("display", "none");
//   });
//   $("#flowers").css("display", "none");
//   $("#flowers").empty();

// }

// function startShowStar(){
//   $(".star").css("opacity", 0);
//   $("#star").css("display", "block");
//   $("#star").css("z-index", "100");

//   var i = 1;
//   var ani = setInterval(function(){
//     $(".star").css("opacity", 0);
//     var t = $("#" + "starEffect_" + i);
//     if (t.length){
//       t.css("opacity", 1);
//     }
//     else{
//       clearInterval(ani);
//       ani = null;
//       $(".star").css("opacity", 0);
//       $("#star").css("display", "none");
//     }
//     i++;
//   }, 50);
// }


// function loadStarAnimation(){
//   function pad(n, width) {
//     n = n + '';
//     return n.length >= width ? n : new Array(width - n.length + 1).join('0') + n;
//   }
//   var div = $("#star");
//   for (var i = 1; i < 32; i++ ){
//     var img = $("<img class='star' style='opacity:0; position:absolute; left:0px; top:0px'>");
//     img.attr("src", "../star/" + i + ".png");
//     img.attr("id", "starEffect_" + i);
//     img.appendTo(div);
//   }
// }


function goNext(){

  var aN = $("#anext");

  aN.on("ended", function(){
    window.location = right_url;
  });
  aN[0].play();

}

function goPrev(){

  var aN = $("#anext");

  aN.on("ended", function(){
    window.location = left_url;
  });
    aN[0].play();
}

function goPage(pageUrl){

  var aN = $("#anext");

  aN.on("ended", function(){
    window.location = pageUrl;
  });
    aN[0].play();
}

/* stop all audio */
function sa() {
  var audios = document.getElementsByTagName("audio");
  for (var i = 0; i < audios.length; i++) {
    var audio = audios[i];
    if (audio.id != "abk") {
      audio.onended = null;
      audio.pause();
      audio.currentTime = 0;
    }
  }
}

/* stop flash */
function sf() {
  flash_index = flash_index + 1;
}

/* play sound */
function pe(audio, start, ended, ex) {
  sa();

  if (play_background == false) {
    play_background = true;
    abackground.volume = 0.5;
    abackground.play().catch(function() {
      play_background = false;
    });
  }

  if (start != null) start();
  audio[0].onended = function () {
    abackground.volume = 0.5;
    if (ended != null) {
      ended();
    }
  }

  abackground.volume = 0.1;
  audio[0].play().catch(function () {
    if (ex != null) ex();
    abackground.volume = 0.5;
  });
}

/* flash element */
function ef(element, ended, count) {
  flash_enable = true;
  var curr_flash_index = flash_index;
  var flash_count = count == null ? 1 : count;
  var flash = function () {
    if (curr_flash_index == flash_index && flash_count > 0) {

      flash_count--;
      element.fadeOut(500).fadeIn(500, flash);
    }

    else if (curr_flash_index == flash_index && flash_count <= 0) {
      if (ended != null) ended();
    }
  };

  flash();
}

/* fade out, move to save location, fade in */
function ff(element, dura) {
  if (dura = null) dura = 100;

  element.fadeOut(dura, function() {
    element.css("left", sl(element));
    element.css("top", st(element));
    element.fadeIn(dura);
  });
}

/* move to save location*/
function mv(element) {
  element.animate({
    left: sl(element),
    top: st(element)
  });
}

/* save left and top */
function sv(element) {

  if (element.length == 1) {
    var id = element.attr("id");
    var left = element.css("left");
    var top = element.css("top");
    location_info[id + "-left"] = left;
    location_info[id + "-top"] = top;
  } else {

    for (var i = 0; i < element.length; i++) {
      var el = element.eq(i);
      var id = el.attr("id");
      var left = el.css("left");
      var top = el.css("top");
      location_info[id + "-left"] = left;
      location_info[id + "-top"] = top;
    }
  }
}

/* get saved left */
function sl(element) {
  var id = element.attr("id");
  return location_info[id + "-left"];
}

/* get saved top */
function st(element) {
  var id = element.attr("id");
  return location_info[id + "-top"];
}

/* fade out element when display */
function fo(element) {
  if (element.length == 1) {
    if (element.css("display") != "none") {
      element.fadeOut(500);
    }
  } else {
    for (var i = 0; i < element.length; i++) {
      var el = element.eq(i);

      if (el.css("display") != "none") {
        el.fadeOut(500);
      }
    }
  }
}

/* fade in element when not display */
function fi(element) {
  if (element.length == 1) {
    if (element.css("display") == "none") {
      element.fadeIn(500);
    }
  } else {
    for (var i = 0; i < element.length; i++) {
      var el = element.eq(i);

      if (el.css("display") == "none") {
        el.fadeIn(500);
      }
    }
  }
}

/* end function : show left / right button */
function ed() {
  if (left_url != null) {
    $("#prev").css("display", "");
    prev = function () {

      if (click_enable == false) return;

      sa();
      sf();
      var anext = $("#anext");
      anext.on("ended", function () {
        window.location = left_url;
      });

      anext[0].play();
      click_enable = false;
    };
  } else {
    $("#prev").css("display", "none");
  }

  if (right_url != null) {
    $("#next").css("display", "");
    next = function () {

      if (click_enable == false) return;

      sa();
      sf();
      var anext = $("#anext");
      anext.on("ended", function () {
        window.location = right_url;
      });

      anext[0].play();
      click_enable = false;
    };
  } else {
    $("#next").css("display", "none");
  }
}

/* 보여지는지 */
function dp(id) {
  return $("#" + id).css("display") != "none";
}

/* 보여지지 않는지 */
function hd(id) {
  return $("#" + id).css("display") == "none";
}

/* 500 ms 이후에 실행 */
function tm(fun) {
  setTimeout(fun, 500);
}

function _trans(ani_idx){
 $("#plus_box").css("opacity","0") ;
 $("#mo_big"+ani_idx).animate({"opacity":"1", "left":"649"}, {duration: 500, easing:"linear"});
 $("#ja").animate({"opacity":"1", "left":"70"}, {duration: 500, easing:"linear"});
 setTimeout(function(){
   var ae = document.getElementById("a"+ani_idx);
   ae.play();
   $("#ja").css("opacity","0");
   $("#mo_big"+ani_idx).css("opacity","0") ;
   $("#fl"+ani_idx).css("opacity","1");
   $("#d"+ani_idx).css("display","none");
   $("#d"+ani_idx).css("opacity","0");
   $("#bl"+ani_idx).css("opacity","1");



   //$(ani_id).animate({"opacity":"1", "top":"0"}, {duration: 500, easing:"linear"});
},800);

}

function popClose(){
  sa();
  $(".popup").css("opacity","0");
  $("#popup,#play_popup").css("z-index","0");
  $("#popClose,#play_popup").css("display","none");
  var audio = document.getElementById("a1");
  audio.onended = null;
  audio.pause();
  audio.currentTime = 0;
}

function popUp(){

  sa();
  $("#popup").css("opacity","1");
  $("#popup").css("z-index","100");
  $("#play_popup").css("z-index","1001");
  $("#popClose,#play_popup").css("display","block");

  var audio = document.getElementById("a_pop");
  audio.play();

}

function _play_audio(file_name){
 sa();
 var ae = document.getElementById(file_name);
 ae.play();
}


function d1() {
    $("#da1").droppable({
      drop: function (event, ui) {
       if (ui.draggable.attr("id") == "d1") {
          sa();
          first = true ;
          $("#ans1").css("opacity","0") ;
          $("#drag1_off").css("opacity","1") ;
          $("#d1").css("display","none") ;
          $("#d1").css("opacity","0") ;

          ff(ui.draggable);

          var au_correct = document.getElementById("a_correct");
          au_correct.play();
          $("#d1").removeAttr("draggable");
          _check_next();
    } else{
        var au_incorrect = document.getElementById("a_incorrect");
        au_incorrect.play() ;
        ff(ui.draggable);
    }
   }

  });
}

function _check_next() {

	if (first == true ) {
    goNextExam();
    // startShowStar();
    setTimeout(function(){
      $("#next").css("display","block");
      $("#next_arrow").css("display","block");
      //$("#prev").css("display","block") ;
      _blink("next_arrow",500);

    },2000) ;
  }
}

function _iclick(idx){
 sa();
 var ae = document.getElementById(idx);
 ae.play();
}


var jj = 1 ;
function _blink(bid,ae) {
    var my_timer = ae ;
    img_blink = setInterval(function(){

    if(jj++ % 2 == 0){
        $("#"+bid).css("opacity","0");
    } else {
        $("#"+bid).css("opacity", "1");
    }
  }, my_timer);
}


function init(){
  var intro = document.getElementById('a_intro');

  intro.onended = function(){

    sv($("#d1, #d2"));
    $("#d1, #d2").draggable({ revert: "invalid" });
    $("#click_pop,.click,#play_audio").css("display","block") ;
    d1();
  }
  intro.play();
  // loadStarAnimation();
}

$(window).on("load", function() {

  init();

});